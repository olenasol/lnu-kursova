package src.secondpr

data class Segment(val startPoint: Pair<Double,Double>,
                   val endPoint: Pair<Double, Double>)